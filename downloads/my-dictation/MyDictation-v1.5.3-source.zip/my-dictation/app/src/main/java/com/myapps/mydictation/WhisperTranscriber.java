package com.myapps.mydictation;

import android.content.Context;
import android.util.Log;
import com.whispercpp.whisper.WhisperLib;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.concurrent.CancellationException;

final class WhisperTranscriber {
    private final WhisperLib.Cancellation cancellation = new WhisperLib.Cancellation();

    void cancel() { cancellation.cancel(); }
    private static final String TAG = "MyDictationWhisper";
    private static final String MODEL_NAME = "ggml-base.bin";
    private static final long MODEL_BYTES = 147_951_465L;
    private static final String MODEL_SHA256 =
            "60ed5bc3dd14eea856493d334349b405782ddcaf0028d4b5df4088345fba2efe";
    private static final String MODEL_URL =
            "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/" + MODEL_NAME;
    private static final int CHUNK_BYTES = PcmRecorder.RATE * 2 * 30;

    interface Callback {
        void downloading();
        void success(String text);
        void failure(String reason);
    }

    void start(Context context, File pcm, Callback callback) {
        Context app = context.getApplicationContext();
        new Thread(() -> {
            try {
                File model = prepareModel(app, callback);
                if (pcm.length() < 3200 || (pcm.length() & 1) != 0) {
                    throw new IOException("The recording is empty, too short, or incomplete.");
                }
                try (InputStream input = new BufferedInputStream(new FileInputStream(pcm))) {
                    String text = WhisperLib.transcribe(model.getAbsolutePath(),
                            () -> pcmChunks(input, pcm.length()), cancellation);
                    if (text.isBlank()) throw new IOException("Whisper did not recognise any speech.");
                    Log.i(TAG, "Offline transcription completed");
                    callback.success(text);
                }
            } catch (CancellationException cancelled) {
                // The editor keeps the pending recording available for retry.
            } catch (Exception | LinkageError | OutOfMemoryError error) {
                Log.e(TAG, "Offline transcription failed", error);
                callback.failure(error instanceof IOException
                        ? error.getMessage() : "Whisper could not process this recording.");
            }
        }, "my-dictation-whisper").start();
    }

    private static synchronized File prepareModel(Context context, Callback callback) throws Exception {
        File directory = context.getFilesDir();
        File model = new File(directory, MODEL_NAME);
        if (model.isFile() && model.length() == MODEL_BYTES) return model;
        callback.downloading();
        File pending = File.createTempFile("whisper-model-", ".part", directory);
        HttpURLConnection download = (HttpURLConnection) URI.create(MODEL_URL).toURL().openConnection();
        download.setConnectTimeout(20_000);
        download.setReadTimeout(30_000);
        try {
            if (download.getResponseCode() != HttpURLConnection.HTTP_OK) {
                throw new IOException("Whisper model download returned HTTP " + download.getResponseCode() + ".");
            }
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            long written;
            try (InputStream source = new DigestInputStream(download.getInputStream(), digest);
                 OutputStream output = new BufferedOutputStream(new FileOutputStream(pending))) {
                written = source.transferTo(output);
            }
            StringBuilder checksum = new StringBuilder();
            for (byte value : digest.digest()) checksum.append(String.format(Locale.ROOT, "%02x", value));
            if (written != MODEL_BYTES || !MODEL_SHA256.contentEquals(checksum)) {
                throw new IOException("Whisper model download was incomplete or corrupt. Please retry.");
            }
            Files.move(pending.toPath(), model.toPath(), StandardCopyOption.ATOMIC_MOVE,
                    StandardCopyOption.REPLACE_EXISTING);
            return model;
        } finally {
            download.disconnect();
            Files.deleteIfExists(pending.toPath());
        }
    }

    private static Iterator<float[]> pcmChunks(InputStream input, long length) {
        return new Iterator<>() {
            private long remaining = length;

            @Override public boolean hasNext() { return remaining > 0; }

            @Override public float[] next() {
                if (!hasNext()) throw new NoSuchElementException();
                int count = (int) Math.min(CHUNK_BYTES, remaining);
                try {
                    byte[] bytes = input.readNBytes(count);
                    if (bytes.length != count) throw new EOFException("Recording ended unexpectedly.");
                    remaining -= count;
                    float[] samples = new float[count / 2];
                    for (int i = 0; i < samples.length; i++) {
                        samples[i] = (short) ((bytes[2 * i] & 255) | (bytes[2 * i + 1] << 8)) / 32768f;
                    }
                    return samples;
                } catch (IOException error) {
                    throw new UncheckedIOException(error);
                }
            }
        };
    }
}
