package com.whispercpp.whisper;

import java.io.IOException;
import java.util.concurrent.CancellationException;

/** Java binding for the JNI entry points in the pinned Notely Voice submodule. */
public final class WhisperLib {
    private static final Companion NATIVE = new Companion();
    private static final Object ACTIVE_LOCK = new Object();
    private static Cancellation active;

    static {
        System.loadLibrary("whisper");
        NATIVE.enableLogcat();
    }

    private WhisperLib() {}

    // The upstream JNI bridge stores a process-wide callback during inference.
    public static synchronized String transcribe(String model, Iterable<float[]> chunks,
                                                 Cancellation cancellation)
            throws IOException {
        cancellation.check();
        long context = NATIVE.initContext(model);
        if (context == 0) throw new IOException("Whisper could not load its speech model.");
        try {
            StringBuilder transcript = new StringBuilder();
            int threads = Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors()));
            for (float[] chunk : chunks) {
                Result result = new Result(cancellation);
                synchronized (ACTIVE_LOCK) {
                    cancellation.check();
                    active = cancellation;
                }
                try {
                    NATIVE.fullTranscribe(context, threads, chunk, "auto", result);
                } finally {
                    synchronized (ACTIVE_LOCK) { active = null; }
                }
                cancellation.check();
                if (!result.complete) throw new IOException("Whisper could not process the audio.");
                String text = result.text.toString().trim();
                if (!text.isEmpty()) {
                    if (transcript.length() > 0) transcript.append(' ');
                    transcript.append(text);
                }
            }
            return transcript.toString();
        } finally {
            NATIVE.freeContext(context);
        }
    }

    public static final class Cancellation {
        private volatile boolean cancelled;

        public boolean isCancelled() { return cancelled; }

        public void cancel() {
            synchronized (ACTIVE_LOCK) {
                cancelled = true;
                if (active == this) NATIVE.stopTranscription();
            }
        }

        public void check() {
            if (cancelled) throw new CancellationException();
        }
    }

    public static final class Result {
        private final StringBuilder text = new StringBuilder();
        private final Cancellation cancellation;
        private boolean complete;

        Result(Cancellation cancellation) { this.cancellation = cancellation; }
        public void onNewSegment(long start, long end, String words) { text.append(words); }
        public void onProgress(int progress) {
            if (cancellation.isCancelled()) NATIVE.stopTranscription();
        }
        public void onComplete() { complete = true; }
    }

    private static final class Companion {
        native void enableLogcat();
        native void stopTranscription();
        native long initContext(String modelPath);
        native void freeContext(long context);
        native void fullTranscribe(long context, int threads, float[] audio, String language, Result callback);
    }
}
