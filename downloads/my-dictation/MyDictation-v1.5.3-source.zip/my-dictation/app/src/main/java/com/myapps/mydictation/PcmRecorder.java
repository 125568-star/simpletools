package com.myapps.mydictation;

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;

final class PcmRecorder {
    static final int RATE = 16000;
    static final int SILENCE_MILLIS = 3000;
    private static final int FRAME_MILLIS = 20;
    private static final int FRAME_BYTES = RATE * FRAME_MILLIS / 1000 * 2;

    static { System.loadLibrary("whisper"); }
    private static native long openVad();
    private static native boolean isSpeech(long vad, byte[] frame);
    private static native void closeVad(long vad);

    private final AtomicBoolean running = new AtomicBoolean();
    private AudioRecord recorder;
    private Thread worker;
    private volatile Exception failure;
    private File output;

    void start(File file, Runnable onStop) throws IOException {
        int minimum = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT);
        if (minimum <= 0) throw new IOException("Microphone format unavailable");
        recorder = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                Math.max(minimum, FRAME_BYTES * 4));
        if (recorder.getState() != AudioRecord.STATE_INITIALIZED) {
            throw new IOException("Could not open microphone");
        }
        output = file;
        recorder.startRecording();
        running.set(true);
        worker = new Thread(() -> capture(onStop), "my-dictation-recorder");
        worker.start();
    }

    private void capture(Runnable onStop) {
        long vad = openVad();
        byte[] frame = new byte[FRAME_BYTES];
        int silence = 0;
        boolean heardSpeech = false;
        try (FileOutputStream stream = new FileOutputStream(output)) {
            if (vad == 0) throw new IOException("Could not initialize speech detection");
            while (running.get()) {
                int count = recorder.read(frame, 0, frame.length, AudioRecord.READ_BLOCKING);
                if (count < 0) {
                    if (!running.get()) break;
                    throw new IOException("Microphone read failed: " + count);
                }
                stream.write(frame, 0, count);
                if (count != frame.length) continue;
                if (isSpeech(vad, frame)) {
                    heardSpeech = true;
                    silence = 0;
                } else if (heardSpeech) {
                    silence += FRAME_MILLIS;
                    if (silence >= SILENCE_MILLIS) break;
                }
            }
            stream.getFD().sync();
        } catch (IOException | RuntimeException error) {
            failure = error;
        } finally {
            if (vad != 0) closeVad(vad);
            if (running.getAndSet(false)) onStop.run();
        }
    }

    boolean isRecording() { return running.get(); }

    void stop() throws Exception {
        running.set(false);
        try {
            recorder.stop();
        } finally {
            if (worker != null) worker.join();
        }
        if (failure != null) throw failure;
        if (output.length() < FRAME_BYTES * 5) throw new IOException("Recording is too short");
    }

    void release() {
        running.set(false);
        if (recorder != null) {
            if (recorder.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) recorder.stop();
            recorder.release();
            recorder = null;
        }
    }
}
