#include <jni.h>
#include <stdint.h>
#include "fvad.h"

JNIEXPORT jlong JNICALL
Java_com_myapps_mydictation_PcmRecorder_openVad(JNIEnv *env, jclass type) {
    Fvad *vad = fvad_new();
    if (vad && (fvad_set_sample_rate(vad, 16000) || fvad_set_mode(vad, 2))) {
        fvad_free(vad);
        vad = NULL;
    }
    return (jlong)(intptr_t)vad;
}

JNIEXPORT jboolean JNICALL
Java_com_myapps_mydictation_PcmRecorder_isSpeech(JNIEnv *env, jclass type, jlong handle, jbyteArray audio) {
    jbyte bytes[640];
    int16_t samples[320];
    (*env)->GetByteArrayRegion(env, audio, 0, 640, bytes);
    for (int i = 0; i < 320; ++i) {
        samples[i] = (int16_t)((uint8_t)bytes[2*i] | ((uint16_t)(uint8_t)bytes[2*i+1] << 8));
    }
    return fvad_process((Fvad *)(intptr_t)handle, samples, 320) == 1;
}

JNIEXPORT void JNICALL
Java_com_myapps_mydictation_PcmRecorder_closeVad(JNIEnv *env, jclass type, jlong handle) {
    fvad_free((Fvad *)(intptr_t)handle);
}
