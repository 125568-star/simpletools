#include <android/log.h>
#include <jni.h>
#include "whisper.h"

static void android_whisper_log(enum ggml_log_level level, const char *message, void *data) {
    (void) data;
    if (level >= GGML_LOG_LEVEL_INFO) {
        __android_log_write(level == GGML_LOG_LEVEL_ERROR ? ANDROID_LOG_ERROR : ANDROID_LOG_INFO,
                            "MyDictationWhisperNative", message);
    }
}

JNIEXPORT void JNICALL Java_com_whispercpp_whisper_WhisperLib_00024Companion_enableLogcat(
        JNIEnv *env, jobject instance) {
    (void) env;
    (void) instance;
    whisper_log_set(android_whisper_log, NULL);
}
