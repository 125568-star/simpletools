# My Dictation

My Dictation is an Android voice-note and checklist app. It records only when you press Record. It stops manually or after three seconds without detected speech. Offline Whisper inserts the result at the selected text or caret and saves it. Failed transcriptions keep the recording available to retry. The first transcription downloads the Whisper model if it is missing.

## Build

Use JDK 17, Gradle 8.11.1, Android SDK 35, NDK 27.0.12077973 and CMake 3.22.1. From a Git checkout, initialize the pinned Notely Voice source with `git submodule update --init --recursive`. The source ZIP already includes the required native code. Run `gradle assembleDebug` from `my-dictation/`.

The default application ID is `com.myapps.mydictation`. Use `-PsideBySide -Parm64Only` for an arm64 build of the existing Offline edition (`com.myapps.mydictation.offline`). Android requires the same signing certificate for an in-place update.

## Windows

Run `windows/C1-Dictation.ps1` in Windows PowerShell 5.1. It requires an installed desktop speech recognizer. Ctrl+Alt+D starts dictation or stops an active session. The tray icon shows when recording. After speech ends, recognized text is entered into the focused field in the same window. Standard text editors and ordinary browser fields are supported by keyboard input. Elevated windows, secure fields and applications that reject synthetic input can block insertion. ChatGPT's built-in microphone runs independently.

## Source and licenses

See [VERSION_INFO.md](VERSION_INFO.md) for the version history. The combined Android app includes the pinned Notely Voice Whisper bridge under [GPLv3](LICENSE). The original Android source notice is retained in [LICENSE-MIT](LICENSE-MIT). The speech activity detector is [libfvad](https://github.com/dpirch/libfvad) at `532ab666c20d3cfda38bca63abbb0f152706c369`, with its license and notices alongside its sources.
