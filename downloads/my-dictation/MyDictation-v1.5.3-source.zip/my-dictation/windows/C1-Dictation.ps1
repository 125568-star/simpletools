param([switch]$Check)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Speech, System.Windows.Forms
Add-Type -ReferencedAssemblies System.Speech,System.Windows.Forms,System.Drawing -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Speech.Recognition;
using System.Windows.Forms;

public sealed class Dictation : Form {
    [DllImport("user32")] static extern bool RegisterHotKey(IntPtr window, int id, uint modifiers, uint key);
    [DllImport("user32")] static extern bool UnregisterHotKey(IntPtr window, int id);
    [DllImport("user32")] static extern IntPtr GetForegroundWindow();

    static readonly TimeSpan Silence = TimeSpan.FromSeconds(3);
    readonly SpeechRecognitionEngine speech = new SpeechRecognitionEngine();
    readonly NotifyIcon tray = new NotifyIcon();
    bool active;
    IntPtr target;
    string words;

    Dictation() {
        ShowInTaskbar = false;
        speech.LoadGrammar(new DictationGrammar());
        speech.EndSilenceTimeout = Silence;
        speech.EndSilenceTimeoutAmbiguous = Silence;
        speech.InitialSilenceTimeout = TimeSpan.FromSeconds(15);
        speech.SetInputToDefaultAudioDevice();
        speech.SpeechHypothesized += (s, e) => { var text = e.Result.Text; BeginInvoke((Action)(() => words = text)); };
        speech.SpeechRecognized += (s, e) => { var text = e.Result.Text; BeginInvoke((Action)(() => words = text)); };
        speech.RecognizeCompleted += (s, e) => BeginInvoke((Action)(() => Complete(e.Error, e.Cancelled)));
        tray.Icon = System.Drawing.SystemIcons.Information;
        tray.Text = "C1 Dictation (Ctrl+Alt+D)";
        tray.ContextMenuStrip = new ContextMenuStrip();
        tray.ContextMenuStrip.Items.Add("Exit", null, (s, e) => Close());
        tray.Visible = true;
        if (!RegisterHotKey(Handle, 1, 0x4003, (uint)Keys.D)) throw new Win32Exception();
    }

    protected override void WndProc(ref Message message) {
        if (message.Msg == 0x0312) {
            if (active) speech.RecognizeAsyncStop();
            else {
                target = GetForegroundWindow();
                words = null;
                active = true;
                tray.Text = "C1 Dictation • Recording";
                try { speech.RecognizeAsync(RecognizeMode.Single); }
                catch (Exception error) { Complete(error, false); }
            }
        }
        base.WndProc(ref message);
    }

    void Complete(Exception error, bool cancelled) {
        active = false;
        tray.Text = "C1 Dictation (Ctrl+Alt+D)";
        if (cancelled || error != null || String.IsNullOrWhiteSpace(words)) return;
        string text = words;
        words = null;
        if (target != GetForegroundWindow()) {
            tray.ShowBalloonTip(4000, "C1 Dictation", "Focus changed. The text was not inserted.", ToolTipIcon.Warning);
            return;
        }
        var escaped = new System.Text.StringBuilder();
        foreach (char c in text) {
            if ("+^%~(){}[]".IndexOf(c) >= 0) escaped.Append('{').Append(c).Append('}');
            else escaped.Append(c);
        }
        SendKeys.SendWait(escaped.ToString());
    }

    protected override void SetVisibleCore(bool value) { base.SetVisibleCore(false); }

    protected override void Dispose(bool disposing) {
        if (disposing) {
            UnregisterHotKey(Handle, 1);
            tray.Dispose();
            speech.Dispose();
        }
        base.Dispose(disposing);
    }

    public static void Run() { Application.Run(new Dictation()); }
}
'@
if ($Check) {
    [System.Speech.Recognition.SpeechRecognitionEngine]::InstalledRecognizers() |
        Select-Object Name, Culture
    return
}
[Dictation]::Run()
