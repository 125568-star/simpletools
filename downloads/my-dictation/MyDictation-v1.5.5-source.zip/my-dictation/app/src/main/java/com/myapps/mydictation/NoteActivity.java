package com.myapps.mydictation;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.graphics.Color;
import android.text.TextWatcher;
import android.text.Editable;
import android.graphics.drawable.GradientDrawable;
import java.io.File;
import java.util.*;

public final class NoteActivity extends Activity {
    private static final int MIC_PERMISSION=71;
    private Database db;
    private long noteId;
    private Note note;
    private EditText titleEdit,bodyEdit;
    private LinearLayout base,itemsBox;
    private TextView status,folderNameView;
    private LinearLayout recIndicator;
    private FrameLayout screen;
    private LinearLayout transcriptionOverlay;
    private TextView transcriptionStatus;
    private boolean recordingTitle, permissionTitle;
    private boolean autoSaving=false;
    private final Runnable autosave=()->saveEdits();
    private Button recordBtn,stopBtn,deleteBtn;
    private PcmRecorder recorder;
    private boolean transcriptionRunning=false,exitAfterTranscript=false,starting=false;
    private WhisperTranscriber transcription;
    private File recordingFile,recordingDir;
    private long recordStart;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable timer=new Runnable(){@Override public void run(){if((recorder!=null&&recorder.isRecording())&&status!=null){long s=(System.currentTimeMillis()-recordStart)/1000;status.setText("● Recording  "+(s/60)+":"+String.format(Locale.ROOT,"%02d",s%60));handler.postDelayed(this,500);}}};

    @Override public void onCreate(Bundle b){super.onCreate(b);db=new Database(this);noteId=getIntent().getLongExtra("id",-1);note=db.read(noteId);if(note==null){finish();return;}recordingDir=new File(getFilesDir(),"recordings");recordingDir.mkdirs();render();}
    private void render(){
        note=db.read(noteId);if(note==null)return;
        base=Ui.vertical(this);base.setBackgroundColor(Ui.BG);
        // The REC lamp is centred independently of the Back button.
        FrameLayout header=new FrameLayout(this);
        Button back=Ui.secondary(this,"‹ Folders");
        FrameLayout.LayoutParams backLp=new FrameLayout.LayoutParams(-2,-2,Gravity.START|Gravity.CENTER_VERTICAL);
        header.addView(back,backLp);
        back.setOnClickListener(v->leave());
        deleteBtn = Ui.secondary(this, "Delete note");
        LinearLayout noteActions = Ui.horizontal(this);
        ImageButton save = new ImageButton(this);
        save.setImageResource(R.drawable.ic_save_note);
        save.setContentDescription("Save Note");
        save.setTooltipText("Save Note");
        noteActions.addView(save, new LinearLayout.LayoutParams(Ui.dp(this, 48), Ui.dp(this, 48)));
        save.setOnClickListener(v -> leave());
        noteActions.addView(deleteBtn);
        header.addView(noteActions, new FrameLayout.LayoutParams(-2, -2,
                Gravity.END | Gravity.CENTER_VERTICAL));
        deleteBtn.setOnClickListener(v -> confirmDeleteNote());
        recIndicator=Ui.horizontal(this);
        View dot=new View(this);
        GradientDrawable dotBg=Ui.shape(Color.rgb(241,54,54),this);
        dotBg.setCornerRadius(Ui.dp(this,50));
        dot.setBackground(dotBg);
        LinearLayout.LayoutParams dotLp=new LinearLayout.LayoutParams(Ui.dp(this,9),Ui.dp(this,9));
        dotLp.rightMargin=Ui.dp(this,6);
        recIndicator.addView(dot,dotLp);
        TextView recLabel=Ui.text(this,"REC",14);
        recLabel.setTypeface(null,android.graphics.Typeface.BOLD);
        recLabel.setTextColor(Color.rgb(255,98,98));
        recIndicator.addView(recLabel);
        FrameLayout.LayoutParams recLp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL);
        recLp.topMargin=Ui.dp(this,16);
        header.addView(recIndicator,recLp);
        Ui.add(base,header,0);
        TextView heading=Ui.heading(this,note.kind.equals("note")?"Dictation":"Checklist");
        Ui.add(base,heading,8);
        ScrollView scroll=new ScrollView(this);LinearLayout content=Ui.vertical(this);Ui.pad(content,this,4);scroll.addView(content);
        titleEdit=Ui.edit(this,"Title");titleEdit.setSingleLine(true);titleEdit.setText(note.title);titleEdit.setTextSize(22);Ui.add(content,titleEdit,8);
        LinearLayout tools=Ui.horizontal(this);
        Button folder=Ui.secondary(this,"Put into Folder");tools.addView(folder,new LinearLayout.LayoutParams(0,-2,1));folder.setOnClickListener(v->chooseFolder());
        Button color=Ui.secondary(this,"Colour");tools.addView(color,new LinearLayout.LayoutParams(0,-2,1));color.setOnClickListener(v->chooseColour());
        Ui.add(content,tools,8);
        folderNameView=Ui.text(this,"Folder: "+note.folder,13);
        folderNameView.setTextColor(Ui.MUTED);
        Ui.add(content,folderNameView,6);
        bodyEdit=Ui.edit(this,"Write or dictate your note...");
        bodyEdit.setText(note.body);
        bodyEdit.setMinLines(note.kind.equals("note")?7:2);
        bodyEdit.setGravity(Gravity.TOP|Gravity.START);
        // An actual outlined, black writing area, with readable white text.
        GradientDrawable editor=Ui.shape(Color.BLACK,this);
        editor.setStroke(Ui.dp(this,1.5f),Color.rgb(104,127,180));
        editor.setCornerRadius(Ui.dp(this,12));
        bodyEdit.setBackground(editor);
        bodyEdit.setBackgroundTintList(null);
        bodyEdit.setTextColor(Color.WHITE);
        bodyEdit.setTypeface(null, android.graphics.Typeface.NORMAL);
        bodyEdit.setHintTextColor(Color.rgb(160,160,160));
        Ui.pad(bodyEdit,this,12);
        Ui.add(content,bodyEdit,12);
        TextWatcher editWatcher=new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){scheduleAutosave();}
            @Override public void afterTextChanged(Editable e){}
        };
        titleEdit.addTextChangedListener(editWatcher);
        bodyEdit.addTextChangedListener(editWatcher);
        if(!"note".equals(note.kind)){
            itemsBox=Ui.vertical(this);Ui.add(content,itemsBox,12);renderItems();
            LinearLayout addLine=Ui.horizontal(this);EditText itemText=Ui.edit(this,"New checklist item");addLine.addView(itemText,new LinearLayout.LayoutParams(0,-2,1));
            Button add=Ui.button(this,"Add");addLine.addView(add);add.setOnClickListener(v->{db.addItem(noteId,itemText.getText().toString());itemText.setText("");renderItems();});Ui.add(content,addLine,8);
        }
        base.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout bottom=Ui.vertical(this);Ui.pad(bottom,this,10);bottom.setBackground(Ui.shape(Ui.CARD,this));
        status=Ui.text(this,"Ready to dictate",14);status.setTextColor(Ui.MUTED);bottom.addView(status);
        LinearLayout actions=Ui.horizontal(this);
        // Separate tape-recorder controls. No recording on opening a note.
        recordBtn=Ui.button(this,"●  Record");
        actions.addView(recordBtn,new LinearLayout.LayoutParams(0,-2,1));
        recordBtn.setOnClickListener(v -> beginRecording(titleEdit.hasFocus()));
        stopBtn=Ui.secondary(this,"■  Stop");
        LinearLayout.LayoutParams stopLp=new LinearLayout.LayoutParams(0,-2,1);
        stopLp.leftMargin=Ui.dp(this,8);
        actions.addView(stopBtn,stopLp);
        stopBtn.setOnClickListener(v->{
            if (transcriptionRunning) {
                cancelTranscription();
                render();
                status.setText("Transcription stopped. Record a new take or retry.");
            } else endAndTranscribe();
        });
        Ui.add(bottom,actions,8);
        Ui.add(base,bottom,0);Ui.pad(base,this,14);
        screen = new FrameLayout(this);
        base.setFocusableInTouchMode(true);
        screen.addView(base, new FrameLayout.LayoutParams(-1, -1));
        transcriptionOverlay = Ui.vertical(this);
        transcriptionOverlay.setGravity(Gravity.CENTER);
        transcriptionOverlay.setBackgroundColor(Ui.BG);
        transcriptionOverlay.setClickable(true);
        transcriptionOverlay.setFocusableInTouchMode(true);
        Ui.add(transcriptionOverlay, Ui.text(this, "⌛", 132), 0);
        transcriptionStatus = Ui.text(this, "Transcribing…", 22);
        transcriptionStatus.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        Ui.add(transcriptionOverlay, transcriptionStatus, 12);
        Button cancel = Ui.secondary(this, "■ Stop");
        Ui.add(transcriptionOverlay, cancel, 16);
        cancel.setOnClickListener(v -> stopBtn.performClick());
        screen.addView(transcriptionOverlay, new FrameLayout.LayoutParams(-1, -1));
        setContentView(screen);
        base.requestFocus();
        updateRecordingButtons();
        if(note.audioState.equals("PENDING")&&!transcriptionRunning){status.setText("Untranscribed recording saved — retry available");Button retry=Ui.secondary(this,"Retry transcription");Ui.add(bottom,retry,5);retry.setOnClickListener(v->retry());}
        if(note.audioState.equals("VERIFIED")){status.setText("Transcript saved — audio deletion available");Button deletion=Ui.secondary(this,"Delete transcribed audio");Ui.add(bottom,deletion,5);deletion.setOnClickListener(v->askDeleteAudio(false));}
    }
    private void renderItems(){if(itemsBox==null)return;itemsBox.removeAllViews();for(Database.ChecklistItem item:db.items(noteId)){
        LinearLayout row=Ui.horizontal(this);row.setBackground(Ui.shape(Ui.CARD,this));Ui.pad(row,this,4);
        CheckBox box=new CheckBox(this);box.setButtonTintList(android.content.res.ColorStateList.valueOf(Ui.PRIMARY));box.setText(item.text);box.setTextColor(Ui.TEXT);box.setChecked(item.checked);row.addView(box,new LinearLayout.LayoutParams(0,-2,1));box.setOnCheckedChangeListener((b,checked)->db.checked(item.id,checked));
        Button options=Ui.secondary(this,"⋮");row.addView(options);options.setOnClickListener(v->itemActions(item));Ui.add(itemsBox,row,6);
    }}
    private void itemActions(Database.ChecklistItem item){new AlertDialog.Builder(this).setTitle(item.text).setItems(new String[]{"Edit","Move up","Move down","Delete"},(d,which)->{
        if(which==0){EditText e=Ui.edit(this,"Item");e.setText(item.text);new AlertDialog.Builder(this).setTitle("Edit item").setView(e).setNegativeButton("Cancel",null).setPositiveButton("Save",(x,y)->{db.renameItem(item.id,e.getText().toString());renderItems();}).show();}
        else if(which==1||which==2){db.moveItem(noteId,item.id,which==1?-1:1);renderItems();}
        else{db.deleteItem(item.id);renderItems();}
    }).show();}
    private void chooseFolder(){String[] names=db.folders().toArray(new String[0]);String[] options=Arrays.copyOf(names,names.length+1);options[names.length]="+ New Folder";
        new AlertDialog.Builder(this).setTitle("Put into Folder").setItems(options,(d,which)->{
            if(which==names.length){EditText e=Ui.edit(this,"Folder name");new AlertDialog.Builder(this).setTitle("New Folder").setView(e).setNegativeButton("Cancel",null).setPositiveButton("Save",(x,y)->{String name=e.getText().toString().trim();if(!name.isEmpty()){saveEdits();db.setFolder(noteId,name);render();}}).show();}
            else{saveEdits();db.setFolder(noteId,options[which]);render();}
        }).show();}
    private void chooseColour(){final String[] colours={"Default dark","Yellow","Blue","Green","Orange","Pink","Grey","White"};final int[] values={Ui.CARD,0xFFFFF4AB,0xFFBEDAFF,0xFFC7EFD0,0xFFFFD2A8,0xFFFFC8E8,0xFFD5D9E1,0xFFFFFFFF};new AlertDialog.Builder(this).setTitle("Note background colour").setItems(colours,(d,i)->{saveEdits();db.setColor(noteId,values[i]);render();}).show();}
    private void scheduleAutosave(){
        handler.removeCallbacks(autosave);
        handler.postDelayed(autosave,450);
    }
    private void saveEdits(){
        handler.removeCallbacks(autosave);
        if(autoSaving||db==null||titleEdit==null||bodyEdit==null)return;
        autoSaving=true;
        try{db.update(noteId,titleEdit.getText().toString(),bodyEdit.getText().toString());}
        finally{autoSaving=false;}
    }
    private void updateRecordingButtons(){
        boolean active=recorder!=null&&recorder.isRecording();
        if(recIndicator!=null)recIndicator.setVisibility(active?View.VISIBLE:View.INVISIBLE);
        if(recordBtn==null||stopBtn==null)return;
        recordBtn.setEnabled(recorder == null);
        stopBtn.setEnabled(active || transcriptionRunning);
        deleteBtn.setEnabled(recorder == null && !transcriptionRunning);
        transcriptionOverlay.setVisibility(transcriptionRunning ? View.VISIBLE : View.GONE);
        base.setImportantForAccessibility(transcriptionRunning
                ? View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
                : View.IMPORTANT_FOR_ACCESSIBILITY_AUTO);
        if (transcriptionRunning) {
            transcriptionStatus.setText("Transcribing…");
            transcriptionOverlay.requestFocus();
            getSystemService(android.view.inputmethod.InputMethodManager.class)
                    .hideSoftInputFromWindow(screen.getWindowToken(), 0);
        }
        recordBtn.setText("●  Record");
        stopBtn.setText("■  Stop");
        if(active)status.setText("● Recording...");
        else if(transcriptionRunning)status.setText("Transcribing...");
    }
    private void beginRecording(boolean title){
        if(starting || recorder != null)return;
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            permissionTitle = title;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},MIC_PERMISSION);
            return;
        }
        starting=true;
        try{
            saveEdits();
            cancelTranscription();
            recordingTitle = title;
            recordingFile = new File(recordingDir, "recording_" + noteId + "_" +
                    (recordingTitle ? "title_" : "") +
                    System.currentTimeMillis() + ".pcm");
            PcmRecorder current = new PcmRecorder();
            recorder = current;
            current.start(recordingFile, () -> handler.post(() -> {
                if (recorder == current) endAndTranscribe();
            }));
            recordStart = System.currentTimeMillis();
            handler.post(timer);
            updateRecordingButtons();
        } catch (Exception error) {
            if (recorder != null) recorder.release();
            recorder = null;
            render();
            showError("Recording could not start", error.getMessage());
        }finally{starting=false;}
    }
    @Override public void onRequestPermissionsResult(int request,String[] perms,int[] grants){super.onRequestPermissionsResult(request,perms,grants);if(request==MIC_PERMISSION){if(grants.length>0&&grants[0]==PackageManager.PERMISSION_GRANTED)beginRecording(permissionTitle);else Toast.makeText(this,"Microphone permission is needed for dictation",Toast.LENGTH_LONG).show();}}
    private void endAndTranscribe() {
        if (recorder == null) return;
        PcmRecorder current = recorder;
        recorder = null;
        handler.removeCallbacks(timer);
        try {
            current.stop();
            saveEdits();
            saveTake();
            retry();
        } catch (Exception error) {
            if (recordingFile.isFile() && recordingFile.length() >= 3200) {
                saveTake();
            }
            render();
            showError("Recording stopped", error.getMessage());
        } finally {
            current.release();
            updateRecordingButtons();
        }
    }

    private void saveTake() {
        Note previous = db.read(noteId);
        db.setRecording(noteId, recordingFile.getAbsolutePath());
        if (previous != null && "PENDING".equals(previous.audioState)
                && !recordingFile.getAbsolutePath().equals(previous.audioPath)) {
            File oldTake = new File(previous.audioPath);
            if (recordingDir.equals(oldTake.getParentFile())) oldTake.delete();
        }
    }

    private void cancelTranscription() {
        if (transcription == null) return;
        transcription.cancel();
        transcription = null;
        transcriptionRunning = false;
        exitAfterTranscript = false;
    }

    private void retry() {
        if (transcriptionRunning || recorder != null) return;
        Note pending = db.read(noteId);
        if (pending == null || !"PENDING".equals(pending.audioState)) return;
        File audio = new File(pending.audioPath);
        if (!audio.isFile()) {
            showError("Audio unavailable", "The saved recording could not be found.");
            return;
        }
        long id = noteId;
        android.content.Context app = getApplicationContext();
        transcriptionRunning = true;
        updateRecordingButtons();
        WhisperTranscriber job = new WhisperTranscriber();
        transcription = job;
        job.start(app, audio, new WhisperTranscriber.Callback() {
            @Override public void downloading() {
                handler.post(() -> {
                    if (transcription == job && !isDestroyed())
                        transcriptionStatus.setText("Downloading the offline Whisper model…");
                });
            }

            @Override public void success(String words) {
                handler.post(() -> {
                    if (transcription != job) return;
                    try (Database target = new Database(app)) {
                        if (!isDestroyed()) saveEdits();
                        target.saveRecordingTranscript(id, audio, words);
                        target.deleteAudio(id, new File(app.getFilesDir(), "recordings"));
                        transcription = null;
                        if (!isDestroyed()) {
                            transcriptionRunning = false;
                            if (exitAfterTranscript) finish();
                            else {
                                render();
                                bodyEdit.setSelection(bodyEdit.length());
                                status.setText("Transcription saved");
                            }
                        }
                    } catch (Exception error) {
                        failure(error.getMessage());
                    }
                });
            }

            @Override public void failure(String reason) {
                handler.post(() -> {
                    if (transcription != job || isDestroyed()) return;
                    transcription = null;
                    transcriptionRunning = false;
                    exitAfterTranscript = false;
                    render();
                    showError("Recording kept for retry", reason);
                });
            }
        });
    }

    private void confirmDeleteNote() {
        new AlertDialog.Builder(this)
                .setTitle("Delete this note?")
                .setMessage("This permanently deletes the note, its checklist items and associated recordings.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (dialog, button) -> {
                    try {
                        if (db.deleteNotes(Collections.singleton(noteId), recordingDir) != 1) {
                            throw new IllegalStateException("The note could not be found.");
                        }
                        handler.removeCallbacks(autosave);
                        finish();
                    } catch (Exception error) {
                        showError("Could not delete note", error.getMessage());
                    }
                }).show();
    }

    private void askDeleteAudio(boolean leaveAfter){new AlertDialog.Builder(this).setTitle("Transcription saved").setMessage("Delete the audio recording? The saved text will remain.")
        .setNegativeButton("Keep Audio",(d,w)->{db.keepAudio(noteId);if(leaveAfter)finish();else render();})
        .setPositiveButton("Delete Audio",(d,w)->{boolean deleted=db.deleteAudio(noteId,recordingDir);Toast.makeText(this,deleted?"Audio deleted":"Audio could not be deleted",Toast.LENGTH_LONG).show();if(leaveAfter)finish();else render();})
        .setCancelable(false).show();}
    private void showError(String title,String message){new AlertDialog.Builder(this).setTitle(title).setMessage(message==null?"Unknown error":message).setPositiveButton("OK",null).show();}
    private void leave() {
        saveEdits();
        if (recorder != null) {
            exitAfterTranscript = true;
            endAndTranscribe();
        } else if (transcriptionRunning) {
            exitAfterTranscript = true;
            finish();
        } else {
            finish();
        }
    }
    @Override public void onBackPressed() { if (!transcriptionRunning) leave(); }

    @Override protected void onPause() {
        if (recorder != null) endAndTranscribe();
        else saveEdits();
        super.onPause();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(autosave);
        handler.removeCallbacks(timer);
        if (recorder != null) recorder.release();
        if (db != null) db.close();
        super.onDestroy();
    }
}
