package au.tarik.s23compass;

final class Qibla {
    static final double LATITUDE = 21.4225;
    static final double LONGITUDE = 39.82617;

    static float trueBearing(double latitude, double longitude) {
        double from = Math.toRadians(latitude);
        double to = Math.toRadians(LATITUDE);
        double longitudeDelta = Math.toRadians(LONGITUDE - longitude);
        double east = Math.sin(longitudeDelta) * Math.cos(to);
        double north = Math.cos(from) * Math.sin(to)
                - Math.sin(from) * Math.cos(to) * Math.cos(longitudeDelta);
        if (Math.hypot(east, north) < 1e-10) return Float.NaN;
        return (float)((Math.toDegrees(Math.atan2(east, north)) + 360) % 360);
    }

    private Qibla() {}
}
