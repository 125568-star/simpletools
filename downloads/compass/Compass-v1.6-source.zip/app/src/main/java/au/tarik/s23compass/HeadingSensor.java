package au.tarik.s23compass;

import android.content.Context;
import android.hardware.*;

final class HeadingSensor implements SensorEventListener {
    interface Callback { void onHeading(float heading); }
    private final SensorManager manager;
    private final Callback callback;
    private final float[] matrix = new float[9], gravity = new float[3], field = new float[3];
    private boolean haveGravity, haveField, active, useCameraAxis;
    private float aimHeading = Float.NaN;
    HeadingSensor(Context context, Callback callback) {
        manager = context.getSystemService(SensorManager.class);
        this.callback = callback;
    }
    boolean start(int period) {
        if (active) return true;
        if (manager == null) return false;
        aimHeading = Float.NaN;
        useCameraAxis = false;
        haveGravity = haveField = false;
        Sensor rotation = manager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        if (rotation != null && manager.registerListener(this, rotation, period)) return active = true;
        Sensor accel = manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        Sensor mag = manager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        if (accel != null && mag != null && manager.registerListener(this, accel, period)
                && manager.registerListener(this, mag, period)) return active = true;
        manager.unregisterListener(this);
        return false;
    }
    void stop() {
        if (manager != null) manager.unregisterListener(this);
        active = false;
    }
    @Override public void onSensorChanged(SensorEvent e) {
        if (!active) return;
        if (e.sensor.getType() == Sensor.TYPE_ROTATION_VECTOR) {
            SensorManager.getRotationMatrixFromVector(matrix, e.values);
        } else {
            boolean accel = e.sensor.getType() == Sensor.TYPE_ACCELEROMETER;
            float[] target = accel ? gravity : field;
            boolean have = accel ? haveGravity : haveField;
            for (int i=0; i<3; i++) target[i] = have ? target[i] + 0.25f*(e.values[i]-target[i]) : e.values[i];
            if (accel) haveGravity = true; else haveField = true;
            if (!haveGravity || !haveField || !SensorManager.getRotationMatrix(matrix, null, gravity, field)) return;
        }
        // Rows point east, north and up. Columns Y and -Z are the top edge and rear camera.
        float tilt = Math.abs(matrix[7]) - Math.abs(matrix[8]);
        boolean aimAlongCamera = tilt > (useCameraAxis ? -0.12f : 0.12f);
        float aim = aimAlongCamera
                ? (float)Math.toDegrees(Math.atan2(-matrix[2], -matrix[5]))
                : (float)Math.toDegrees(Math.atan2(matrix[1], matrix[4]));
        if (!Float.isFinite(aim)) return;
        aimHeading = smooth(aimAlongCamera == useCameraAxis ? aimHeading : Float.NaN, aim);
        useCameraAxis = aimAlongCamera;
        callback.onHeading(aimHeading);
    }
    private static float smooth(float previous, float raw) {
        return normalize(Float.isFinite(previous) ? previous + 0.25f*difference(raw, previous) : raw);
    }
    static float normalize(float value) { return (value % 360 + 360) % 360; }
    static float difference(float a, float b) { return normalize(a - b + 180) - 180; }
    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}
}
