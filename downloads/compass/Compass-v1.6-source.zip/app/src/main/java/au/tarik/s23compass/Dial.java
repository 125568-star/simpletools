package au.tarik.s23compass;

import android.graphics.*;

final class Dial {
    static final int INK = 0xffeef4ff, MUTED = 0xffa6b6c9, RED = 0xffff575f;
    static final int GOLD = 0xffffce71;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path arrow = new Path();

    static int degrees(float heading) { return Math.round(heading) % 360; }
    static String direction(float heading) {
        return new String[]{"N","NE","E","SE","S","SW","W","NW"}[((int)((heading + 22.5f) / 45)) % 8];
    }

    void draw(Canvas c, float width, float height, float heading, float qiblaOffset) {
        float side = Math.min(width, height);
        c.save();
        c.translate((width-side)/2, (height-side)/2);
        c.scale(side/100, side/100);
        boolean showQibla = Float.isFinite(qiblaOffset);
        drawFace(c, showQibla ? -heading : 0);
        if (Float.isFinite(heading)) {
            c.save();
            c.rotate(-heading, 50, 50);
            triangle(c, 25, 0xffd3e0f0);
            triangle(c, -25, RED);
            c.restore();
        }
        circle(c, 50, 50, 3.1f, 0xff101721);
        circle(c, 50, 50, 1.8f, INK);
        if (showQibla) drawQibla(c, qiblaOffset);
        c.restore();
    }

    private void drawFace(Canvas c, float rotation) {
        circle(c, 50, 50, 49, 0xff141d29);
        circle(c, 50, 50, 47.2f, 0xff3b4b60);
        circle(c, 50, 50, 45.8f, 0xff192434);
        c.save();
        c.rotate(rotation, 50, 50);
        for (int i=0; i<60; i++) {
            c.save();
            c.rotate(i*6, 50, 50);
            p.setColor(i%5==0 ? 0xffa6b6c9 : 0xff566982);
            p.setStrokeWidth(i%5==0 ? 0.9f : 0.45f);
            c.drawLine(50, 6.8f, 50, i%5==0 ? 11 : 9, p);
            c.restore();
        }
        label(c, "N", 50, 19, RED);
        label(c, "E", 81, 50, INK);
        label(c, "S", 50, 81, INK);
        label(c, "W", 19, 50, INK);
        c.restore();
        circle(c, 50, 50, 24, 0xff26354a);
        circle(c, 50, 50, 23.4f, 0xff192434);
    }

    private void drawQibla(Canvas c, float offset) {
        double radians = Math.toRadians(offset);
        float x = 50 + 41 * (float)Math.sin(radians);
        float y = 50 - 41 * (float)Math.cos(radians);
        circle(c, x, y, 5.5f, GOLD);
        p.setColor(0xff141d29);
        c.drawRoundRect(x-3, y-2.8f, x+3, y+2.8f, 0.5f, 0.5f, p);
        p.setColor(GOLD);
        c.drawRect(x-3, y-1.4f, x+3, y-0.4f, p);
    }

    private void circle(Canvas c, float x, float y, float r, int color) {
        p.setColor(color);
        c.drawCircle(x, y, r, p);
    }
    private void label(Canvas c, String text, float x, float y, int color) {
        p.setColor(color);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        p.setTextSize(9.6f);
        c.drawText(text, x, y-(p.ascent()+p.descent())/2, p);
    }
    private void triangle(Canvas c, int tip, int color) {
        arrow.reset();
        arrow.moveTo(50, 50+tip);
        arrow.lineTo(56.8f, 50);
        arrow.lineTo(43.2f, 50);
        arrow.close();
        p.setColor(color);
        c.drawPath(arrow, p);
    }
}
