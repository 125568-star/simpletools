package au.tarik.s23compass;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Typeface;
import android.hardware.GeomagneticField;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextSwitcher;
import android.widget.TextView;

public final class CompassActivity extends Activity {
    private static final int QIBLA_LOCATION_REQUEST = 1;
    private HeadingSensor sensor;
    private TextView status, qiblaCue;
    private TextSwitcher readout;
    private int shownDegrees = -1;
    private long lastRoll;
    private CompassView dial;
    private LocationManager locations;
    private float magneticQibla = Float.NaN;
    private final LocationListener qiblaLocation = new LocationListener() {
        @Override public void onLocationChanged(Location location) { setQibla(location); }
        @Override public void onProviderEnabled(String provider) { refreshQiblaLocation(); }
        @Override public void onProviderDisabled(String provider) { refreshQiblaLocation(); }
        @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff101721);
        getWindow().setNavigationBarColor(0xff101721);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(0xff101721);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER);
        content.setPadding(dp(24), dp(24), dp(24), dp(24));
        scroll.addView(content, new ScrollView.LayoutParams(-1,-1));
        setContentView(scroll);

        readout = rollingText("—", 40);
        content.addView(readout, new LinearLayout.LayoutParams(-1, -2));
        content.addView(text("MAGNETIC HEADING", 11, Dial.MUTED), row(4));

        dial = new CompassView();
        FrameLayout bezel = new FrameLayout(this);
        bezel.addView(dial, new FrameLayout.LayoutParams(-1,-1));
        int dialSize = Math.min(320, Math.max(140, getResources().getConfiguration().screenWidthDp-58));
        LinearLayout.LayoutParams square = new LinearLayout.LayoutParams(dp(dialSize),dp(dialSize));
        square.topMargin = dp(18);
        content.addView(bezel, square);

        qiblaCue = text("", 17, Dial.GOLD);
        qiblaCue.setTypeface(Typeface.DEFAULT_BOLD);
        qiblaCue.setMinHeight(dp(44));
        content.addView(qiblaCue, row(6));
        locations = getSystemService(LocationManager.class);

        status = text("Aim the back of your phone like a camera, or point the top edge when flat.", 14, Dial.MUTED);
        content.addView(status, row(12));

        sensor = new HeadingSensor(this, aim -> {
            dial.heading = aim;
            updateQiblaCue();
            showHeading(aim);
        });
        CompassWidget.refreshShortcuts(this);
    }

    private void refreshQiblaLocation() {
        locations.removeUpdates(qiblaLocation);
        magneticQibla = Float.NaN;
        updateQiblaCue();
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            qiblaCue.setText("Qibla · Allow approximate location");
            qiblaCue.setOnClickListener(v -> {
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, QIBLA_LOCATION_REQUEST);
            });
            return;
        }
        String provider = locations.getProviders(true).contains("fused") ? "fused" : LocationManager.NETWORK_PROVIDER;
        if (!locations.getProviders(true).contains(provider)) {
            qiblaCue.setText("Qibla · Turn on location");
            qiblaCue.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)));
            return;
        }
        qiblaCue.setOnClickListener(null);
        qiblaCue.setClickable(false);
        qiblaCue.setText("Qibla · Finding your location…");
        try {
            Location cached = locations.getLastKnownLocation(provider);
            if (cached != null && SystemClock.elapsedRealtimeNanos() - cached.getElapsedRealtimeNanos()
                    < 600_000_000_000L) setQibla(cached);
            locations.requestLocationUpdates(provider, 60_000, 250, qiblaLocation);
        } catch (SecurityException | IllegalArgumentException ignored) {
            qiblaCue.setText("Qibla · Location unavailable");
        }
    }

    private void setQibla(Location location) {
        double latitude = location.getLatitude();
        double longitude = location.getLongitude();
        float[] distance = new float[1];
        Location.distanceBetween(latitude, longitude, Qibla.LATITUDE, Qibla.LONGITUDE, distance);
        float bearing = Qibla.trueBearing(latitude, longitude);
        if (!Float.isFinite(bearing) || distance[0] <= Math.max(10f, location.getAccuracy())) {
            magneticQibla = Float.NaN;
            updateQiblaCue();
            qiblaCue.setText("Qibla · Approximate location is too imprecise here");
            return;
        }
        GeomagneticField field = new GeomagneticField((float)latitude, (float)longitude,
                (float)location.getAltitude(), System.currentTimeMillis());
        magneticQibla = HeadingSensor.normalize(bearing - field.getDeclination());
        updateQiblaCue();
    }

    private void updateQiblaCue() {
        dial.qiblaOffset = HeadingSensor.difference(magneticQibla, dial.heading);
        dial.invalidate();
        if (!Float.isFinite(magneticQibla)) return;
        float offset = dial.qiblaOffset;
        String cue;
        if (!Float.isFinite(offset)) cue = "Qibla · Waiting for compass";
        else if (Math.abs(offset) <= 4) cue = "Qibla · Facing the Kaaba";
        else cue = "Qibla · Turn " + Math.round(Math.abs(offset)) + "° " + (offset < 0 ? "left" : "right");
        if (!cue.contentEquals(qiblaCue.getText())) qiblaCue.setText(cue);
    }

    private void showHeading(float heading) {
        long now = SystemClock.elapsedRealtime();
        if (now - lastRoll < 160) return;
        int bearing = Dial.degrees(heading);
        if (shownDegrees >= 0 && (bearing == shownDegrees
                || Math.abs(HeadingSensor.difference(heading, shownDegrees)) < 0.75f)) return;
        lastRoll = now;
        shownDegrees = bearing;
        readout.setText(Dial.direction(bearing) + " " + bearing);
    }

    private TextSwitcher rollingText(String initial, int size) {
        TextSwitcher switcher = new TextSwitcher(this);
        switcher.setFactory(() -> {
            TextView value = text("", size, Dial.INK);
            value.setTypeface(Typeface.DEFAULT_BOLD);
            value.setLayoutParams(new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));
            return value;
        });
        switcher.setInAnimation(roll(1f, 0f));
        switcher.setOutAnimation(roll(0f, -1f));
        switcher.setCurrentText(initial);
        return switcher;
    }

    private static Animation roll(float from, float to) {
        Animation animation = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0,
                Animation.RELATIVE_TO_SELF, 0, Animation.RELATIVE_TO_SELF, from,
                Animation.RELATIVE_TO_SELF, to);
        animation.setDuration(80);
        return animation;
    }

    @Override protected void onResume() {
        super.onResume();
        if (!sensor.start(25000)) status.setText("No magnetic compass sensor is available.");
        refreshQiblaLocation();
    }
    @Override protected void onPause() {
        sensor.stop();
        locations.removeUpdates(qiblaLocation);
        super.onPause();
    }
    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(request, permissions, results);
        if (request == QIBLA_LOCATION_REQUEST && results.length > 0
                && results[0] == PackageManager.PERMISSION_GRANTED) refreshQiblaLocation();
    }
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private LinearLayout.LayoutParams row(int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2,-2);
        p.gravity = Gravity.CENTER_HORIZONTAL;
        p.topMargin = dp(top);
        return p;
    }
    private TextView text(String s, int size, int color) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(size); v.setTextColor(color); v.setGravity(Gravity.CENTER);
        return v;
    }
    private final class CompassView extends View {
        float heading = Float.NaN;
        float qiblaOffset = Float.NaN;
        final Dial face = new Dial();
        CompassView() { super(CompassActivity.this); setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO); }
        @Override protected void onDraw(Canvas canvas) { face.draw(canvas,getWidth(),getHeight(),heading,qiblaOffset); }
    }
}
