package au.tarik.s23compass;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

public final class CompassWidget extends AppWidgetProvider {
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        publish(context, manager, ids);
    }

    static void refreshShortcuts(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, CompassWidget.class));
        if (ids.length > 0) publish(context, manager, ids);
    }

    private static void publish(Context context, AppWidgetManager manager, int[] ids) {
        Intent open = new Intent(context, CompassActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent shortcut = PendingIntent.getActivity(context, 0, open, PendingIntent.FLAG_IMMUTABLE);
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.compass_widget);
        views.setOnClickPendingIntent(R.id.widget, shortcut);
        manager.updateAppWidget(ids, views);
    }
}
